As I work through the AIMl files I come across various missing pieces, usually from the defintion or implementation
of the reference AIML 2 or the Pandora bots

Missing Maps
    number2name

Missing Grammars


