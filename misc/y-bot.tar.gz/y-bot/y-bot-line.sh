#! /bin/sh

clear

python3 -m programy.clients.restful.flask.line.client --config ./config.yaml --cformat yaml --logging ./logging.yaml

