#! /bin/sh

clear

python3 -m programy.clients.events.console.client --config ./config.yaml --cformat yaml --logging ./logging.yaml

